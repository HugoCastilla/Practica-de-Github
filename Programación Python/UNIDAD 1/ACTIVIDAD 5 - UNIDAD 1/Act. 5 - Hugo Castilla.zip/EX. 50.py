# Realiza un programa que de los buenos días 3 veces. Con While

veces=3

while veces>0:
    print("¡Buenos días!")
    veces=veces-1