#Realiza un programa que sume dos números enteros por teclado y presente el resultado por pantalla. El programa preguntará si deseas o no repetir la operación. Con While

res="s"
sum=0

while res=="s":
    num1=int(input("introduce un número: "))
    num2=int(input("introduce otro número: "))
    sum=num1+num2
    print(f"La suma de ambos números es: {sum}")
    res=str(input("Deseas repetir la operación (s/n): "))

print("Programa finalizado.")
